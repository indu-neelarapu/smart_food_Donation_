# 🍲 Smart Food Donation & Rescue System (Java Fullstack)

A modern, responsive **Java Fullstack Web Application** for smart food donation and community food rescue. The platform connects generous food donors (restaurants, caterers, banquet halls, and households) with nearby NGOs and people in need based on **City, Specific Area / Locality, and Keywords**, eliminating food waste and hunger.

---

## 🌟 Key Highlights & Features

1. **Full CRUD Operations**:
   - **Create (Donate Food)**: Post food donations with food name, category, quantity, estimated servings, best before time, donor contact, pickup address, city, area, and photo presets.
   - **Read (Explore & Search)**: Real-time search by keyword (e.g. *Biryani*, *Bread*, *Rice*), category tabs, and status toggles.
   - **Update (Edit Food)**: Edit food quantities, pickup times, contact numbers, or status anytime.
   - **Delete**: Remove expired or completed listings with a single click.
   - **Claim Action**: NGOs or community members can reserve/claim donations with their name/organization.

2. **Smart Location & Area Matching**:
   - **City & Area Filter**: Select city (e.g., *Bangalore*, *Mumbai*, *Hyderabad*, *Chennai*) and type/select specific localities (e.g., *Indiranagar*, *Bandra West*, *Hitech City*, *Koramangala*).
   - **1-Click Card Location Pin**: Click any card's location badge to instantly find all food donations near that area.
   - **Live Pickup Directions**: Exact landmark, phone number, and direct **WhatsApp / Call** links.

3. **Rich Visuals & Responsive Mobile Version**:
   - **Toastify Popups**: Interactive, animated notifications for adding, updating, deleting, claiming, and filtering food.
   - **Responsive Navbar**: Brand logo with pulsating indicator, live available donation pill, and a slide-out drawer menu on mobile devices.
   - **Modern Aesthetic**: Glassmorphism cards, glowing status tags (Available / Claimed), dietary badges (Pure Veg, Non-Veg, Bakery, Cooked Meals, Grocery).

---

## 🛠️ Technology Stack

- **Backend**: Java 21 / 25, Spring Boot 3.3.5, Spring Web (REST API), Spring Data JPA
- **Database**: H2 Database Engine (embedded in-memory database — runs out of the box with zero setup)
- **Frontend**: HTML5, Modern CSS3 (Responsive Grid, Flexbox, Mobile Drawer), Vanilla JavaScript ES6+
- **Libraries**: Toastify.js (notifications), Font Awesome 6 (icons), Google Fonts (Outfit & Plus Jakarta Sans)
- **Build Tool**: Maven Wrapper (`mvnw.cmd` included — no separate Maven installation required)

---

## 🚀 How to Run the Project (Super Easy!)

You do not need to install Maven or configure databases! Everything is pre-configured and automated.

### Option 1: 1-Click Launch (Recommended)
1. Open the project folder: `c:\Users\Indu\Desktop\Smart Food -spring`
2. **Double-click** the file **`run.bat`**
3. It will automatically detect Java, start the Spring Boot server, and open your browser at **http://localhost:8085**!

---

### Option 2: Using Terminal / PowerShell
Open PowerShell or Command Prompt inside this folder and run:
```powershell
.\run.ps1
```
or
```cmd
run.bat
```

---

### Option 3: Using Maven Command Directly
```powershell
$env:JAVA_HOME = "C:\Program Files\Java\jdk-25.0.4"
.\mvnw.cmd spring-boot:run
```
Then open your browser and navigate to:
👉 **http://localhost:8085**

---

## 🧭 How to Use the Application

| Action | How to do it |
| :--- | :--- |
| **Search Food by Name** | Type keywords like `Biryani` or `Bread` into the search bar and press **Search** |
| **Find Food by Location** | Select a **City** (e.g. `Bangalore`) or enter an **Area** (e.g. `Indiranagar`) |
| **Post a Food Donation** | Click the **"Donate Food"** button in the navbar or hero section, fill out the form, and click **Save & Publish** |
| **Claim Food** | Click the **"Claim"** button on any available card, enter your name or NGO, and confirm |
| **View Details & Contact** | Click **"Details"** on any food card to view full pickup instructions, donor phone, and direct WhatsApp button |
| **Edit or Delete** | Use the ✏️ (Edit) or 🗑️ (Delete) buttons on any food card |
| **Test on Mobile** | Open Chrome DevTools (`F12`), toggle device toolbar (mobile view), and test the collapsible hamburger navbar drawer |
| **Inspect Database** | Visit **http://localhost:8085/h2-console** (JDBC URL: `jdbc:h2:mem:smartfooddb`, User: `sa`, Password: empty) |

---

## 📁 Project Directory Structure

```
Smart Food -spring/
├── pom.xml                               # Maven project configuration & dependencies
├── mvnw.cmd / mvnw                       # Bundled Maven wrapper
├── run.bat                               # 1-Click launcher script for Windows
├── run.ps1                               # PowerShell launcher script
├── README.md                             # Project documentation & instructions
├── src/
│   ├── main/
│   │   ├── java/com/smartfood/
│   │   │   ├── SmartFoodApplication.java # Spring Boot main entry point
│   │   │   ├── config/
│   │   │   │   └── DataInitializer.java  # Pre-seeds initial realistic food items
│   │   │   ├── controller/
│   │   │   │   └── FoodDonationController.java # REST API endpoints (/api/donations)
│   │   │   ├── entity/
│   │   │   │   └── FoodDonation.java     # JPA entity model with location & category
│   │   │   ├── repository/
│   │   │   │   └── FoodDonationRepository.java # JPA repository & custom search queries
│   │   │   └── service/
│   │   │       └── FoodDonationService.java # Business logic & calculations
│   │   └── resources/
│   │       ├── application.properties    # Server port (8085) & H2 DB configuration
│   │       └── static/
│   │           ├── index.html            # Main web page with mobile drawer & modals
│   │           ├── css/
│   │           │   └── style.css         # Glassmorphism, card grids, responsive styles
│   │           └── js/
│   │               └── app.js            # Fetch API, Toastify notifications & CRUD logic
```
