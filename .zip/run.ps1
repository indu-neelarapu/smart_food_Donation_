# ==============================================================
# Smart Food Donation System - PowerShell Runner
# ==============================================================

Write-Host "==============================================================" -ForegroundColor Green
Write-Host "       SMART FOOD DONATION SYSTEM - JAVA FULLSTACK           " -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Green
Write-Host ""

# Detect Java JDK
if (-not $env:JAVA_HOME) {
    if (Test-Path "C:\Program Files\Java\jdk-25.0.4") {
        $env:JAVA_HOME = "C:\Program Files\Java\jdk-25.0.4"
    } elseif (Test-Path "C:\Program Files\Java\latest") {
        $env:JAVA_HOME = "C:\Program Files\Java\latest"
    } else {
        $found = Get-ChildItem "C:\Program Files\Java\jdk*" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) {
            $env:JAVA_HOME = $found.FullName
        }
    }
}

if (-not $env:JAVA_HOME) {
    Write-Host "[ERROR] Could not automatically find Java JDK. Please set JAVA_HOME." -ForegroundColor Red
    exit 1
}

Write-Host "[OK] Using Java Home: $env:JAVA_HOME" -ForegroundColor Green

# Free port 8085 if already occupied by any previous instance
$oldPids = Get-NetTCPConnection -LocalPort 8085 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique
if ($oldPids) {
    foreach ($p in $oldPids) {
        Write-Host "[INFO] Freeing port 8085 from previous process (PID: $p)..." -ForegroundColor Yellow
        Stop-Process -Id $p -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "[INFO] Starting Spring Boot application on http://localhost:8085 ..." -ForegroundColor Yellow
Write-Host "[INFO] Web app will open in your browser automatically." -ForegroundColor Cyan
Write-Host "[INFO] Press Ctrl+C in this terminal anytime to stop the server." -ForegroundColor Gray
Write-Host ""

# Schedule opening browser after 4 seconds
Start-Job -ScriptBlock {
    Start-Sleep -Seconds 4
    Start-Process "http://localhost:8085"
} | Out-Null

# Execute Maven wrapper
& .\mvnw.cmd spring-boot:run
