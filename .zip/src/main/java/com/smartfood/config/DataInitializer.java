package com.smartfood.config;

import com.smartfood.entity.FoodDonation;
import com.smartfood.repository.FoodDonationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final FoodDonationRepository repository;

    public DataInitializer(FoodDonationRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() == 0) {
            repository.save(new FoodDonation(
                    "Royal Vegetable Dum Biryani & Raita",
                    "VEG",
                    "30 Meal Boxes",
                    30,
                    "Green Leaf Catering",
                    "+91 98450 12345",
                    "Bangalore",
                    "Indiranagar",
                    "100 Feet Road, 4th Block, Indiranagar",
                    "Today, 10:30 PM",
                    "Surplus fresh food prepared for corporate luncheon. Packed hot in hygienic disposable containers with spoons.",
                    "AVAILABLE",
                    "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=60"
            ));

            repository.save(new FoodDonation(
                    "Fresh Artisanal Sourdough & Croissants",
                    "BAKERY",
                    "25 Assorted Packs",
                    25,
                    "Boulangerie Patisserie",
                    "+91 98200 45678",
                    "Bangalore",
                    "Koramangala",
                    "5th Block, near Sony World Signal, Koramangala",
                    "Tomorrow, 12:00 PM",
                    "Freshly baked morning sourdough loaves, chocolate croissants, and whole wheat baguettes. Sealed in food grade paper bags.",
                    "AVAILABLE",
                    "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=60"
            ));

            repository.save(new FoodDonation(
                    "Wholesome Moong Dal Khichdi & Kadhi",
                    "VEG",
                    "40 Portions",
                    40,
                    "Annapurna Seva Trust",
                    "+91 99111 67890",
                    "Mumbai",
                    "Bandra West",
                    "Hill Road, Bandra West, Mumbai",
                    "Today, 9:00 PM",
                    "Freshly cooked light nutritious khichdi with ghee and spiced buttermilk. Clean containers ready for quick pickup.",
                    "AVAILABLE",
                    "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800&auto=format&fit=crop&q=60"
            ));

            repository.save(new FoodDonation(
                    "Organic Orchard Apples & Sweet Oranges",
                    "GROCERY",
                    "15 Kilograms",
                    50,
                    "Farm Fresh Mart",
                    "+91 97000 89123",
                    "Mumbai",
                    "Andheri East",
                    "MIDC Industrial Area, Andheri East",
                    "Within 3 Days",
                    "Crisp red apples and sweet Nagpur oranges. Donated directly from today's organic market batch.",
                    "AVAILABLE",
                    "https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=800&auto=format&fit=crop&q=60"
            ));

            repository.save(new FoodDonation(
                    "Chicken Dum Biryani & Salan",
                    "NON_VEG",
                    "20 Meal Packs",
                    20,
                    "Grand Hyderabad Banquet",
                    "+91 94400 33221",
                    "Hyderabad",
                    "Hitech City",
                    "Cyber Towers, Madhapur, Hitech City",
                    "Today, 11:00 PM",
                    "Carefully preserved leftover event meal packs. High protein chicken dum biryani with mirchi ka salan.",
                    "AVAILABLE",
                    "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=800&auto=format&fit=crop&q=60"
            ));

            repository.save(new FoodDonation(
                    "Traditional South Indian Rice & Sambar",
                    "COOKED_MEAL",
                    "50 Meal Packets",
                    50,
                    "Sri Krishna Kalyana Mandapam",
                    "+91 98840 55443",
                    "Chennai",
                    "T. Nagar",
                    "G.N. Chetty Road, T. Nagar, Chennai",
                    "Today, 8:00 PM",
                    "Auspicious wedding ceremony lunch surplus. Sona Masoori rice, drumstick sambar, potato fry, and payasam.",
                    "CLAIMED",
                    "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=60"
            ));

            System.out.println(">>> Sample food donation records pre-loaded successfully! <<<");
        }
    }
}
