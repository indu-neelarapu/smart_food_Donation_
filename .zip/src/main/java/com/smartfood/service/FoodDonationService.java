package com.smartfood.service;

import com.smartfood.entity.FoodDonation;
import com.smartfood.repository.FoodDonationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
public class FoodDonationService {

    private final FoodDonationRepository repository;

    public FoodDonationService(FoodDonationRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<FoodDonation> getAllDonations() {
        return repository.findAllByOrderByCreatedAtDesc();
    }

    @Transactional(readOnly = true)
    public Optional<FoodDonation> getDonationById(Long id) {
        return repository.findById(id);
    }

    public FoodDonation createDonation(FoodDonation donation) {
        if (donation.getStatus() == null || donation.getStatus().isBlank()) {
            donation.setStatus("AVAILABLE");
        }
        if (donation.getServings() == null || donation.getServings() <= 0) {
            donation.setServings(1);
        }
        return repository.save(donation);
    }

    public FoodDonation updateDonation(Long id, FoodDonation updated) {
        FoodDonation existing = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Food donation not found with id: " + id));

        existing.setFoodName(updated.getFoodName());
        existing.setCategory(updated.getCategory());
        existing.setQuantity(updated.getQuantity());
        existing.setServings(updated.getServings() != null ? updated.getServings() : existing.getServings());
        existing.setDonorName(updated.getDonorName());
        existing.setDonorPhone(updated.getDonorPhone());
        existing.setCity(updated.getCity());
        existing.setArea(updated.getArea());
        existing.setAddress(updated.getAddress());
        existing.setBestBefore(updated.getBestBefore());
        existing.setDescription(updated.getDescription());
        if (updated.getStatus() != null && !updated.getStatus().isBlank()) {
            existing.setStatus(updated.getStatus());
        }
        if (updated.getImageUrl() != null && !updated.getImageUrl().isBlank()) {
            existing.setImageUrl(updated.getImageUrl());
        }
        if (updated.getClaimedBy() != null) {
            existing.setClaimedBy(updated.getClaimedBy());
        }

        return repository.save(existing);
    }

    public void deleteDonation(Long id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Food donation not found with id: " + id);
        }
        repository.deleteById(id);
    }

    public FoodDonation claimDonation(Long id, String claimedBy) {
        FoodDonation donation = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Food donation not found with id: " + id));

        donation.setStatus("CLAIMED");
        donation.setClaimedBy((claimedBy != null && !claimedBy.isBlank()) ? claimedBy.trim() : "Community Member / NGO");
        return repository.save(donation);
    }

    @Transactional(readOnly = true)
    public List<FoodDonation> searchDonations(String keyword, String city, String area, String category, String status) {
        String kw = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        String c = (city != null && !city.trim().isEmpty()) ? city.trim() : null;
        String a = (area != null && !area.trim().isEmpty()) ? area.trim() : null;
        String cat = (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) ? category.trim() : null;
        String st = (status != null && !status.trim().isEmpty() && !status.equalsIgnoreCase("ALL")) ? status.trim() : null;

        return repository.searchAndFilter(kw, c, a, cat, st);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getLocations() {
        Map<String, Object> locations = new HashMap<>();
        locations.put("cities", repository.findDistinctCities());
        locations.put("areas", repository.findDistinctAreas());
        return locations;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getStatistics() {
        List<FoodDonation> all = repository.findAll();
        long totalDonations = all.size();
        long available = all.stream().filter(d -> "AVAILABLE".equalsIgnoreCase(d.getStatus())).count();
        long claimed = all.stream().filter(d -> "CLAIMED".equalsIgnoreCase(d.getStatus())).count();
        int totalServings = all.stream().mapToInt(d -> d.getServings() != null ? d.getServings() : 0).sum();
        long distinctCities = all.stream().map(FoodDonation::getCity).filter(c -> c != null && !c.isBlank()).distinct().count();

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalDonations", totalDonations);
        stats.put("availableDonations", available);
        stats.put("claimedDonations", claimed);
        stats.put("totalServings", totalServings);
        stats.put("citiesCovered", distinctCities);
        return stats;
    }
}
