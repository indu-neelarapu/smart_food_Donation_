package com.smartfood.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "food_donations")
public class FoodDonation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String foodName;

    @Column(nullable = false)
    private String category; // VEG, NON_VEG, BAKERY, GROCERY, COOKED_MEAL

    @Column(nullable = false)
    private String quantity;

    private Integer servings; // Estimated number of people it can feed

    @Column(nullable = false)
    private String donorName;

    @Column(nullable = false)
    private String donorPhone;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String area;

    @Column(length = 500)
    private String address;

    private String bestBefore; // e.g. "Today, 9:00 PM"

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private String status = "AVAILABLE"; // AVAILABLE, RESERVED, CLAIMED

    private String claimedBy;

    @Column(length = 500)
    private String imageUrl;

    private LocalDateTime createdAt;

    public FoodDonation() {
        this.createdAt = LocalDateTime.now();
    }

    public FoodDonation(String foodName, String category, String quantity, Integer servings,
                        String donorName, String donorPhone, String city, String area,
                        String address, String bestBefore, String description,
                        String status, String imageUrl) {
        this.foodName = foodName;
        this.category = category;
        this.quantity = quantity;
        this.servings = servings;
        this.donorName = donorName;
        this.donorPhone = donorPhone;
        this.city = city;
        this.area = area;
        this.address = address;
        this.bestBefore = bestBefore;
        this.description = description;
        this.status = (status != null && !status.isBlank()) ? status : "AVAILABLE";
        this.imageUrl = imageUrl;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
        if (this.status == null || this.status.isBlank()) {
            this.status = "AVAILABLE";
        }
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public Integer getServings() {
        return servings;
    }

    public void setServings(Integer servings) {
        this.servings = servings;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public String getDonorPhone() {
        return donorPhone;
    }

    public void setDonorPhone(String donorPhone) {
        this.donorPhone = donorPhone;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBestBefore() {
        return bestBefore;
    }

    public void setBestBefore(String bestBefore) {
        this.bestBefore = bestBefore;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getClaimedBy() {
        return claimedBy;
    }

    public void setClaimedBy(String claimedBy) {
        this.claimedBy = claimedBy;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
