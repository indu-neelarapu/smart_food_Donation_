package com.smartfood.controller;

import com.smartfood.entity.FoodDonation;
import com.smartfood.service.FoodDonationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/donations")
@CrossOrigin(origins = "*")
public class FoodDonationController {

    private final FoodDonationService service;

    public FoodDonationController(FoodDonationService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<FoodDonation>> getAllDonations(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String area,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String status) {

        if ((keyword != null && !keyword.isBlank()) ||
            (city != null && !city.isBlank()) ||
            (area != null && !area.isBlank()) ||
            (category != null && !category.isBlank()) ||
            (status != null && !status.isBlank())) {
            return ResponseEntity.ok(service.searchDonations(keyword, city, area, category, status));
        }
        return ResponseEntity.ok(service.getAllDonations());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getDonationById(@PathVariable Long id) {
        return service.getDonationById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    public ResponseEntity<?> createDonation(@RequestBody FoodDonation donation) {
        if (donation.getFoodName() == null || donation.getFoodName().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Food name is required"));
        }
        if (donation.getDonorName() == null || donation.getDonorName().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Donor name is required"));
        }
        if (donation.getDonorPhone() == null || donation.getDonorPhone().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Donor phone is required"));
        }
        if (donation.getCity() == null || donation.getCity().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "City is required"));
        }
        if (donation.getArea() == null || donation.getArea().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Area is required"));
        }

        FoodDonation created = service.createDonation(donation);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateDonation(@PathVariable Long id, @RequestBody FoodDonation updated) {
        try {
            FoodDonation saved = service.updateDonation(id, updated);
            return ResponseEntity.ok(saved);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDonation(@PathVariable Long id) {
        try {
            service.deleteDonation(id);
            return ResponseEntity.ok(Map.of("message", "Food donation deleted successfully", "id", id));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{id}/claim")
    public ResponseEntity<?> claimDonation(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> body) {
        try {
            String claimedBy = (body != null && body.containsKey("claimedBy")) ? body.get("claimedBy") : null;
            FoodDonation claimed = service.claimDonation(id, claimedBy);
            return ResponseEntity.ok(claimed);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/locations")
    public ResponseEntity<Map<String, Object>> getLocations() {
        return ResponseEntity.ok(service.getLocations());
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStats() {
        return ResponseEntity.ok(service.getStatistics());
    }
}
