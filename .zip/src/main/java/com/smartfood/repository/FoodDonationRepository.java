package com.smartfood.repository;

import com.smartfood.entity.FoodDonation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodDonationRepository extends JpaRepository<FoodDonation, Long> {

    List<FoodDonation> findAllByOrderByCreatedAtDesc();

    @Query("SELECT f FROM FoodDonation f WHERE " +
           "(:keyword IS NULL OR :keyword = '' OR " +
           " LOWER(f.foodName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(f.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(f.donorName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(f.city) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           " LOWER(f.area) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:city IS NULL OR :city = '' OR LOWER(f.city) = LOWER(:city)) AND " +
           "(:area IS NULL OR :area = '' OR LOWER(f.area) = LOWER(:area)) AND " +
           "(:category IS NULL OR :category = '' OR f.category = :category) AND " +
           "(:status IS NULL OR :status = '' OR f.status = :status) " +
           "ORDER BY f.createdAt DESC")
    List<FoodDonation> searchAndFilter(
            @Param("keyword") String keyword,
            @Param("city") String city,
            @Param("area") String area,
            @Param("category") String category,
            @Param("status") String status);

    @Query("SELECT DISTINCT f.city FROM FoodDonation f WHERE f.city IS NOT NULL ORDER BY f.city ASC")
    List<String> findDistinctCities();

    @Query("SELECT DISTINCT f.area FROM FoodDonation f WHERE f.area IS NOT NULL ORDER BY f.area ASC")
    List<String> findDistinctAreas();

    long countByStatus(String status);
}
