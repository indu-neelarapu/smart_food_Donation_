/**
 * SmartFood - Java Fullstack Application Logic
 * Supports Real-time CRUD, Live Updates, Location/Area Matching, Toastify Popups, and Mobile Drawer
 */

const API_BASE = '/api/donations';

// State Management
let allDonations = [];
let currentFilterCategory = 'ALL';
let currentDonationEditing = null;
let isUserSearching = false;
let liveSyncInterval = null;

// Image Preset Library
const IMAGE_PRESETS = {
  biryani: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=60',
  bakery: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=60',
  fruits: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=800&auto=format&fit=crop&q=60',
  curry: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800&auto=format&fit=crop&q=60',
  sandwich: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=60',
  default: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=60'
};

// ==========================================
// Toastify Popup Notification Utility
// ==========================================
function showToast(message, type = 'success') {
  let className = 'toastify-success';

  if (type === 'error') {
    className = 'toastify-error';
  } else if (type === 'info') {
    className = 'toastify-info';
  } else if (type === 'warning') {
    className = 'toastify-warning';
  }

  if (window.Toastify) {
    Toastify({
      text: `${message}`,
      duration: 3500,
      gravity: 'top',
      position: 'right',
      escapeMarkup: false,
      className: className,
      stopOnFocus: true,
      style: {
        borderRadius: '12px',
        fontWeight: '600'
      }
    }).showToast();
  } else {
    alert(message);
  }
}

// ==========================================
// Initialization & Mobile Navigation
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
  initMobileNavigation();
  loadDonations();
  loadLocations();
  loadStats();
  startLiveUpdates(); // Real-time background sync
});

function initMobileNavigation() {
  const toggleBtn = document.getElementById('mobile-toggle');
  const navMenu = document.getElementById('nav-menu');
  const overlay = document.getElementById('drawer-overlay');

  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('open');
      toggleBtn.classList.toggle('active', isOpen);
      if (overlay) overlay.classList.toggle('active', isOpen);
    });

    // Close on link click
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => closeMobileMenu());
    });
  }
}

function closeMobileMenu() {
  const toggleBtn = document.getElementById('mobile-toggle');
  const navMenu = document.getElementById('nav-menu');
  const overlay = document.getElementById('drawer-overlay');

  if (toggleBtn) toggleBtn.classList.remove('active');
  if (navMenu) navMenu.classList.remove('open');
  if (overlay) overlay.classList.remove('active');
}

// ==========================================
// Live Real-Time Polling & Sync
// ==========================================
function startLiveUpdates() {
  if (liveSyncInterval) clearInterval(liveSyncInterval);

  // Poll every 6 seconds in background
  liveSyncInterval = setInterval(async () => {
    // Only background sync if user is not actively typing in an input
    const activeEl = document.activeElement;
    const isTyping = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT');
    const isModalOpen = document.body.classList.contains('modal-open');

    if (!isTyping && !isModalOpen && !isUserSearching) {
      try {
        const res = await fetch(API_BASE);
        if (res.ok) {
          const freshData = await res.json();
          // Check if data changed
          if (JSON.stringify(freshData) !== JSON.stringify(allDonations)) {
            allDonations = freshData;
            renderDonationCards(allDonations);
            loadStats();
            loadLocations();
          }
        }
      } catch (e) {
        // Silent catch for background polling
      }
    }
  }, 6000);
}

// ==========================================
// Data Fetching & Locations
// ==========================================
async function loadDonations(queryParams = '') {
  const loadingEl = document.getElementById('loading-state');
  const emptyEl = document.getElementById('empty-state');
  const gridEl = document.getElementById('food-grid');
  const resultLabel = document.getElementById('result-count-label');

  if (!queryParams && loadingEl) loadingEl.style.display = 'block';
  if (emptyEl) emptyEl.style.display = 'none';

  try {
    const url = queryParams ? `${API_BASE}?${queryParams}` : API_BASE;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch food donations');

    const data = await res.json();
    allDonations = data;

    if (loadingEl) loadingEl.style.display = 'none';

    if (!data || data.length === 0) {
      if (gridEl) gridEl.innerHTML = '';
      if (emptyEl) emptyEl.style.display = 'block';
      if (resultLabel) resultLabel.textContent = '0 donations found matching criteria';
    } else {
      if (emptyEl) emptyEl.style.display = 'none';
      renderDonationCards(data);
      if (resultLabel) {
        resultLabel.textContent = `Showing ${data.length} verified surplus food item${data.length > 1 ? 's' : ''}`;
      }
    }
  } catch (err) {
    console.error('Error fetching donations:', err);
    if (loadingEl) loadingEl.style.display = 'none';
    if (emptyEl) emptyEl.style.display = 'block';
    showToast('Failed to connect to backend server. Make sure Spring Boot is running.', 'error');
  }
}

async function loadLocations() {
  try {
    const res = await fetch(`${API_BASE}/locations`);
    if (!res.ok) return;
    const data = await res.json();

    const citySelect = document.getElementById('search-city');
    if (citySelect && data.cities) {
      const currentSelected = citySelect.value;
      citySelect.innerHTML = '<option value="">All Cities</option>';
      data.cities.forEach(city => {
        const opt = document.createElement('option');
        opt.value = city;
        opt.textContent = city;
        if (city === currentSelected) opt.selected = true;
        citySelect.appendChild(opt);
      });
    }

    const areaDatalist = document.getElementById('area-datalist');
    if (areaDatalist && data.areas) {
      areaDatalist.innerHTML = '';
      data.areas.forEach(area => {
        const opt = document.createElement('option');
        opt.value = area;
        areaDatalist.appendChild(opt);
      });
    }
  } catch (e) {
    console.warn('Could not load location hints:', e);
  }
}

async function loadStats() {
  try {
    const res = await fetch(`${API_BASE}/stats`);
    if (!res.ok) return;
    const data = await res.json();

    const mealsEl = document.getElementById('stat-meals');
    const activeEl = document.getElementById('stat-active');
    const citiesEl = document.getElementById('stat-cities');
    const claimedEl = document.getElementById('stat-claimed');
    const activeBadge = document.getElementById('active-count-badge');

    if (mealsEl) mealsEl.textContent = `${data.totalServings || 0}+`;
    if (activeEl) activeEl.textContent = data.availableDonations || 0;
    if (citiesEl) citiesEl.textContent = data.citiesCovered || 0;
    if (claimedEl) claimedEl.textContent = data.claimedDonations || 0;
    if (activeBadge) activeBadge.textContent = `Live: ${data.availableDonations || 0} Available`;
  } catch (e) {
    console.warn('Could not load stats:', e);
  }
}

// ==========================================
// Rendering Food Cards
// ==========================================
function renderDonationCards(items) {
  const gridEl = document.getElementById('food-grid');
  const emptyEl = document.getElementById('empty-state');
  if (!gridEl) return;

  gridEl.innerHTML = '';

  if (!items || items.length === 0) {
    if (emptyEl) emptyEl.style.display = 'block';
    return;
  }

  if (emptyEl) emptyEl.style.display = 'none';

  items.forEach(item => {
    const isClaimed = (item.status || '').toUpperCase() === 'CLAIMED';
    const card = document.createElement('div');
    card.className = `food-card ${isClaimed ? 'claimed' : ''}`;
    card.id = `donation-card-${item.id}`;

    // Category styling & labels
    let catClass = 'veg';
    let catLabel = '🟢 Pure Veg';
    if (item.category === 'NON_VEG') { catClass = 'non_veg'; catLabel = '🔴 Non-Veg'; }
    else if (item.category === 'BAKERY') { catClass = 'bakery'; catLabel = '🍞 Bakery'; }
    else if (item.category === 'GROCERY') { catClass = 'grocery'; catLabel = '🍎 Grocery'; }
    else if (item.category === 'COOKED_MEAL') { catClass = 'cooked_meal'; catLabel = '🍲 Cooked Meal'; }

    // Fallback image based on category
    const displayImg = item.imageUrl && item.imageUrl.trim() !== ''
      ? item.imageUrl
      : (IMAGE_PRESETS[catClass] || IMAGE_PRESETS.default);

    card.innerHTML = `
      <div class="food-card-img-wrap">
        <img class="food-card-img" src="${escapeHtml(displayImg)}" alt="${escapeHtml(item.foodName)}" loading="lazy" onerror="this.src='${IMAGE_PRESETS.default}'">
        <div class="card-top-tags">
          <span class="category-tag ${catClass}">${catLabel}</span>
          <span class="status-tag ${isClaimed ? 'claimed-badge' : 'available'}">
            ${isClaimed ? '<i class=\"fa-solid fa-check\"></i> Claimed' : '<i class=\"fa-solid fa-clock\"></i> Available'}
          </span>
        </div>
        <span class="servings-overlay-badge">
          <i class="fa-solid fa-people-roof"></i> Serves ~${item.servings || 1}
        </span>
      </div>

      <div class="food-card-body">
        <div class="card-title-row">
          <h3 class="card-food-title">${escapeHtml(item.foodName)}</h3>
          <div class="card-quantity-text"><i class="fa-solid fa-cubes"></i> ${escapeHtml(item.quantity)}</div>
        </div>

        <!-- Location Badge (Clickable to filter by this area!) -->
        <button class="card-location-badge" onclick="filterByLocation('${escapeJs(item.city)}', '${escapeJs(item.area)}')" title="Click to view all food in ${escapeHtml(item.area)}, ${escapeHtml(item.city)}">
          <i class="fa-solid fa-location-dot"></i>
          <span>${escapeHtml(item.area)}, ${escapeHtml(item.city)}</span>
        </button>

        <div class="card-meta-list">
          <div class="card-meta-item">
            <i class="fa-solid fa-hourglass-half"></i>
            <span>Best Before: <strong>${escapeHtml(item.bestBefore || 'Consume soon')}</strong></span>
          </div>
          <div class="card-meta-item">
            <i class="fa-solid fa-user-circle"></i>
            <span>Donor: ${escapeHtml(item.donorName)}</span>
          </div>
        </div>

        <p class="card-description">${escapeHtml(item.description || 'Surplus clean food offered by donor.')}</p>

        <div class="card-footer">
          ${isClaimed ? `
            <div class="claimed-notice-banner">
              <i class="fa-solid fa-hand-holding-heart"></i> Claimed by: <strong>${escapeHtml(item.claimedBy || 'Community Member')}</strong>
            </div>
            <button class="card-icon-action" onclick="viewDetails(${item.id})" title="View Details">
              <i class="fa-solid fa-eye"></i>
            </button>
            <button class="card-icon-action delete-icon" onclick="deleteDonation(${item.id})" title="Delete Listing">
              <i class="fa-solid fa-trash"></i>
            </button>
          ` : `
            <button class="btn btn-secondary card-btn-claim" onclick="viewDetails(${item.id})">
              <i class="fa-solid fa-circle-info"></i> Details
            </button>
            <button class="btn btn-primary" onclick="openClaimModal(${item.id}, '${escapeJs(item.foodName)}')">
              <i class="fa-solid fa-hand-holding-heart"></i> Claim
            </button>
            <button class="card-icon-action" onclick="editDonation(${item.id})" title="Edit Details">
              <i class="fa-solid fa-pen-to-square"></i>
            </button>
            <button class="card-icon-action delete-icon" onclick="deleteDonation(${item.id})" title="Delete Listing">
              <i class="fa-solid fa-trash"></i>
            </button>
          `}
        </div>
      </div>
    `;

    gridEl.appendChild(card);
  });
}

// ==========================================
// Search, Filter & Location Matching
// ==========================================
function handleSearch(event) {
  if (event) event.preventDefault();

  const keyword = document.getElementById('search-keyword').value.trim();
  const city = document.getElementById('search-city').value.trim();
  const area = document.getElementById('search-area').value.trim();
  const onlyAvailable = document.getElementById('only-available-toggle').checked;

  isUserSearching = Boolean(keyword || city || area || (currentFilterCategory && currentFilterCategory !== 'ALL'));

  const params = new URLSearchParams();
  if (keyword) params.append('keyword', keyword);
  if (city) params.append('city', city);
  if (area) params.append('area', area);
  if (currentFilterCategory && currentFilterCategory !== 'ALL') {
    params.append('category', currentFilterCategory);
  }
  if (onlyAvailable) {
    params.append('status', 'AVAILABLE');
  }

  // Active filter badge
  updateActiveFilterIndicator(keyword, city, area);

  loadDonations(params.toString());
  showToast(`Searching nearby food matching your filters...`, 'info');
}

function handleCityChange() {
  handleSearch();
}

function handleAvailableToggle() {
  handleSearch();
}

function selectCategory(btn, category) {
  currentFilterCategory = category;
  document.querySelectorAll('.category-pills .pill-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  handleSearch();
}

// Filter when clicking on any card's location badge
function filterByLocation(city, area) {
  const citySelect = document.getElementById('search-city');
  const areaInput = document.getElementById('search-area');

  if (citySelect) {
    citySelect.value = city;
  }
  if (areaInput) {
    areaInput.value = area;
  }

  handleSearch();
  showToast(`Filtering food near ${area}, ${city}`, 'info');

  const exploreEl = document.getElementById('explore');
  if (exploreEl) {
    exploreEl.scrollIntoView({ behavior: 'smooth' });
  }
}

function resetSearchFilters() {
  const kw = document.getElementById('search-keyword');
  const city = document.getElementById('search-city');
  const area = document.getElementById('search-area');
  const toggle = document.getElementById('only-available-toggle');

  if (kw) kw.value = '';
  if (city) city.value = '';
  if (area) area.value = '';
  if (toggle) toggle.checked = true;

  currentFilterCategory = 'ALL';
  isUserSearching = false;

  document.querySelectorAll('.category-pills .pill-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.category === 'ALL');
  });

  const filterBar = document.getElementById('active-filter-bar');
  if (filterBar) filterBar.style.display = 'none';

  loadDonations('status=AVAILABLE');
  showToast('Filters reset. Showing all available donations.', 'info');
}

function updateActiveFilterIndicator(keyword, city, area) {
  const filterBar = document.getElementById('active-filter-bar');
  const textEl = document.getElementById('filter-summary-text');
  if (!filterBar || !textEl) return;

  const parts = [];
  if (keyword) parts.push(`"${keyword}"`);
  if (city) parts.push(`City: ${city}`);
  if (area) parts.push(`Area: ${area}`);
  if (currentFilterCategory !== 'ALL') parts.push(`Type: ${currentFilterCategory}`);

  if (parts.length > 0) {
    textEl.textContent = parts.join(' • ');
    filterBar.style.display = 'flex';
  } else {
    filterBar.style.display = 'none';
  }
}

// ==========================================
// CRUD Operations: Create & Update
// ==========================================
function openDonateModal(isEdit = false) {
  const modal = document.getElementById('donate-modal');
  const form = document.getElementById('donation-form');
  const title = document.getElementById('modal-form-title');
  const sub = document.getElementById('modal-form-subtitle');
  const submitBtn = document.getElementById('btn-submit-donation');

  if (!modal || !form) return;

  closeMobileMenu();

  if (!isEdit) {
    currentDonationEditing = null;
    form.reset();
    document.getElementById('form-donation-id').value = '';
    title.textContent = 'Donate Surplus Food';
    sub.textContent = 'Fill in details to list available food for nearby rescue';
    submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Save & Publish Food';

    // Helpful default suggestions
    document.getElementById('form-servings').value = 10;
    document.getElementById('form-quantity').value = '10 Meal Boxes';
    document.getElementById('form-best-before').value = 'Today, 9:00 PM';
    document.getElementById('form-city').value = 'Bangalore';
    document.getElementById('form-area').value = 'Indiranagar';
  }

  modal.classList.add('open');
  document.body.classList.add('modal-open');

  // Focus food name input after open
  setTimeout(() => {
    const nameInput = document.getElementById('form-food-name');
    if (nameInput) nameInput.focus();
  }, 100);
}

function closeDonateModal() {
  const modal = document.getElementById('donate-modal');
  if (modal) modal.classList.remove('open');
  document.body.classList.remove('modal-open');
}

function selectImagePreset(type) {
  const imgInput = document.getElementById('form-image-url');
  if (imgInput && IMAGE_PRESETS[type]) {
    imgInput.value = IMAGE_PRESETS[type];
    showToast(`Preset image selected: ${type.toUpperCase()}`, 'info');
  }
}

async function handleDonationSubmit(event) {
  event.preventDefault();

  const id = document.getElementById('form-donation-id').value;
  const foodName = document.getElementById('form-food-name').value.trim();
  const category = document.getElementById('form-category').value;
  const quantity = document.getElementById('form-quantity').value.trim();
  const servings = parseInt(document.getElementById('form-servings').value, 10) || 1;
  const city = document.getElementById('form-city').value.trim();
  const area = document.getElementById('form-area').value.trim();
  const address = document.getElementById('form-address').value.trim();
  const bestBefore = document.getElementById('form-best-before').value.trim();
  const status = document.getElementById('form-status').value;
  const donorName = document.getElementById('form-donor-name').value.trim();
  const donorPhone = document.getElementById('form-donor-phone').value.trim();
  const description = document.getElementById('form-description').value.trim();
  let imageUrl = document.getElementById('form-image-url').value.trim();

  // Field validation
  if (!foodName) {
    showToast('Please enter the food name', 'warning');
    document.getElementById('form-food-name').focus();
    return;
  }
  if (!quantity) {
    showToast('Please enter the quantity', 'warning');
    document.getElementById('form-quantity').focus();
    return;
  }
  if (!city) {
    showToast('Please enter the city', 'warning');
    document.getElementById('form-city').focus();
    return;
  }
  if (!area) {
    showToast('Please enter the specific area/locality', 'warning');
    document.getElementById('form-area').focus();
    return;
  }
  if (!donorName) {
    showToast('Please enter your donor/restaurant name', 'warning');
    document.getElementById('form-donor-name').focus();
    return;
  }
  if (!donorPhone) {
    showToast('Please enter donor contact phone', 'warning');
    document.getElementById('form-donor-phone').focus();
    return;
  }

  if (!imageUrl) {
    const key = category ? category.toLowerCase() : 'default';
    imageUrl = IMAGE_PRESETS[key] || IMAGE_PRESETS.default;
  }

  const payload = {
    foodName,
    category,
    quantity,
    servings,
    city,
    area,
    address,
    bestBefore,
    status,
    donorName,
    donorPhone,
    description,
    imageUrl
  };

  const submitBtn = document.getElementById('btn-submit-donation');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

  try {
    const isUpdating = id && id.trim() !== '';
    const url = isUpdating ? `${API_BASE}/${id}` : API_BASE;
    const method = isUpdating ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to save donation');
    }

    const savedItem = await res.json();

    closeDonateModal();

    // LIVE INSTANT UPDATE IN FRONTEND!
    if (isUpdating) {
      const idx = allDonations.findIndex(d => d.id === savedItem.id);
      if (idx !== -1) {
        allDonations[idx] = savedItem;
      } else {
        allDonations.unshift(savedItem);
      }
      showToast(`✏️ "${savedItem.foodName}" updated live!`, 'success');
    } else {
      // Prepend newly created item directly at top
      allDonations.unshift(savedItem);
      showToast(`🎉 "${savedItem.foodName}" posted live! Thank you for donating!`, 'success');
    }

    // Immediately re-render cards
    renderDonationCards(allDonations);

    // Highlight the card with glowing animation and scroll to view
    setTimeout(() => {
      const cardEl = document.getElementById(`donation-card-${savedItem.id}`);
      if (cardEl) {
        cardEl.classList.add('newly-added');
        cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 150);

    // Refresh counters and location dropdowns
    loadStats();
    loadLocations();
  } catch (err) {
    console.error('Error saving donation:', err);
    showToast(`Error: ${err.message}`, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Save & Publish Food';
  }
}

// Edit existing donation
async function editDonation(id) {
  try {
    const res = await fetch(`${API_BASE}/${id}`);
    if (!res.ok) throw new Error('Could not fetch donation');
    const data = await res.json();

    currentDonationEditing = data;

    document.getElementById('form-donation-id').value = data.id;
    document.getElementById('form-food-name').value = data.foodName || '';
    document.getElementById('form-category').value = data.category || 'VEG';
    document.getElementById('form-quantity').value = data.quantity || '';
    document.getElementById('form-servings').value = data.servings || 1;
    document.getElementById('form-city').value = data.city || '';
    document.getElementById('form-area').value = data.area || '';
    document.getElementById('form-address').value = data.address || '';
    document.getElementById('form-best-before').value = data.bestBefore || '';
    document.getElementById('form-status').value = data.status || 'AVAILABLE';
    document.getElementById('form-donor-name').value = data.donorName || '';
    document.getElementById('form-donor-phone').value = data.donorPhone || '';
    document.getElementById('form-description').value = data.description || '';
    document.getElementById('form-image-url').value = data.imageUrl || '';

    const title = document.getElementById('modal-form-title');
    const sub = document.getElementById('modal-form-subtitle');
    const submitBtn = document.getElementById('btn-submit-donation');
    if (title) title.textContent = 'Edit Food Donation Details';
    if (sub) sub.textContent = `Update information for #${data.id} ${data.foodName}`;
    if (submitBtn) submitBtn.innerHTML = '<i class="fa-solid fa-check"></i> Save Changes';

    openDonateModal(true);
  } catch (e) {
    showToast('Failed to load donation details for edit: ' + e.message, 'error');
  }
}

// ==========================================
// CRUD Operations: Delete
// ==========================================
async function deleteDonation(id) {
  const confirmed = confirm('Are you sure you want to delete this food donation post?');
  if (!confirmed) return;

  try {
    const res = await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete item');

    // LIVE REMOVAL FROM FRONTEND
    allDonations = allDonations.filter(d => d.id !== id);
    renderDonationCards(allDonations);

    showToast('🗑️ Food donation removed successfully.', 'info');
    closeDetailsModal();
    loadStats();
    loadLocations();
  } catch (err) {
    console.error('Delete error:', err);
    showToast('Could not delete item: ' + err.message, 'error');
  }
}

// ==========================================
// View Details Modal
// ==========================================
async function viewDetails(id) {
  try {
    const res = await fetch(`${API_BASE}/${id}`);
    if (!res.ok) throw new Error('Failed to load item');
    const item = await res.json();

    const isClaimed = (item.status || '').toUpperCase() === 'CLAIMED';

    document.getElementById('modal-detail-title').textContent = item.foodName;
    document.getElementById('modal-detail-category-badge').textContent = item.category;
    document.getElementById('modal-detail-category-badge').className = `badge category-tag ${item.category.toLowerCase()}`;
    
    const imgEl = document.getElementById('modal-detail-img');
    imgEl.src = item.imageUrl || IMAGE_PRESETS.default;

    const statusBadge = document.getElementById('modal-detail-status-badge');
    statusBadge.textContent = isClaimed ? 'Claimed' : 'Available for Pickup';
    statusBadge.style.background = isClaimed ? '#475569' : '#10b981';

    document.getElementById('modal-detail-quantity').textContent = item.quantity;
    document.getElementById('modal-detail-servings').textContent = `~${item.servings || 1} people`;
    document.getElementById('modal-detail-bestbefore').textContent = item.bestBefore || 'Consume soon';

    document.getElementById('modal-detail-city').innerHTML = `<i class="fa-solid fa-city"></i> ${item.city}`;
    document.getElementById('modal-detail-area').innerHTML = `<i class="fa-solid fa-map-pin"></i> ${item.area}`;
    document.getElementById('modal-detail-address').textContent = item.address || 'Address provided upon contact.';

    document.getElementById('modal-detail-desc').textContent = item.description || 'No additional instructions provided.';
    document.getElementById('modal-detail-donor-name').textContent = item.donorName;

    // Contact buttons
    const phoneBtn = document.getElementById('modal-detail-phone-btn');
    phoneBtn.href = `tel:${item.donorPhone}`;
    phoneBtn.innerHTML = `<i class="fa-solid fa-phone"></i> ${item.donorPhone}`;

    const cleanPhone = (item.donorPhone || '').replace(/[^0-9]/g, '');
    const whatsappBtn = document.getElementById('modal-detail-whatsapp-btn');
    whatsappBtn.href = `https://wa.me/${cleanPhone}?text=Hi%20${encodeURIComponent(item.donorName)},%20I%20am%20interested%20in%20picking%20up%20your%20food%20donation%20for%20${encodeURIComponent(item.foodName)}.`;

    // Modal action buttons
    const deleteBtn = document.getElementById('modal-detail-delete-btn');
    deleteBtn.onclick = () => deleteDonation(item.id);

    const editBtn = document.getElementById('modal-detail-edit-btn');
    editBtn.onclick = () => {
      closeDetailsModal();
      editDonation(item.id);
    };

    const claimBtn = document.getElementById('modal-detail-claim-btn');
    if (isClaimed) {
      claimBtn.style.display = 'none';
    } else {
      claimBtn.style.display = 'inline-flex';
      claimBtn.onclick = () => {
        closeDetailsModal();
        openClaimModal(item.id, item.foodName);
      };
    }

    document.getElementById('details-modal').classList.add('open');
    document.body.classList.add('modal-open');
  } catch (err) {
    showToast('Error loading details: ' + err.message, 'error');
  }
}

function closeDetailsModal() {
  const modal = document.getElementById('details-modal');
  if (modal) modal.classList.remove('open');
  document.body.classList.remove('modal-open');
}

// ==========================================
// Claim Modal
// ==========================================
function openClaimModal(id, foodName) {
  document.getElementById('claim-item-id').value = id;
  document.getElementById('claim-food-name-label').textContent = foodName;
  document.getElementById('claim-name').value = '';
  document.getElementById('claim-modal').classList.add('open');
  document.body.classList.add('modal-open');

  setTimeout(() => {
    const claimInput = document.getElementById('claim-name');
    if (claimInput) claimInput.focus();
  }, 100);
}

function closeClaimModal() {
  const modal = document.getElementById('claim-modal');
  if (modal) modal.classList.remove('open');
  document.body.classList.remove('modal-open');
}

async function handleClaimSubmit(event) {
  event.preventDefault();

  const id = document.getElementById('claim-item-id').value;
  const claimer = document.getElementById('claim-name').value.trim();

  if (!claimer) {
    showToast('Please enter your name or organization name', 'warning');
    return;
  }

  const confirmBtn = document.getElementById('btn-confirm-claim');
  confirmBtn.disabled = true;
  confirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Reserving...';

  try {
    const res = await fetch(`${API_BASE}/${id}/claim`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ claimedBy: claimer })
    });

    if (!res.ok) throw new Error('Failed to claim donation');

    const updated = await res.json();

    closeClaimModal();

    // LIVE FRONTEND UPDATE
    const idx = allDonations.findIndex(d => d.id === updated.id);
    if (idx !== -1) {
      allDonations[idx] = updated;
    }
    renderDonationCards(allDonations);
    loadStats();

    showToast(`🎉 Thank you, ${claimer}! Successfully claimed "${updated.foodName}"!`, 'success');
  } catch (err) {
    console.error('Claim error:', err);
    showToast('Failed to claim: ' + err.message, 'error');
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.innerHTML = '<i class="fa-solid fa-check"></i> Confirm & Claim';
  }
}

// ==========================================
// Security & Helpers
// ==========================================
function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function escapeJs(text) {
  if (!text) return '';
  return String(text).replace(/'/g, "\\'");
}

// Close modals when clicking backdrop
document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      backdrop.classList.remove('open');
      document.body.classList.remove('modal-open');
    }
  });
});

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-backdrop.open').forEach(m => m.classList.remove('open'));
    document.body.classList.remove('modal-open');
    closeMobileMenu();
  }
});
