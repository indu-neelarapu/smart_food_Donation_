@echo off
title Smart Food Donation - Java Fullstack Application
color 0A

echo ==============================================================
echo       WELCOME TO SMART FOOD DONATION SYSTEM
echo ==============================================================
echo.

:: Check JAVA_HOME or find Java JDK
if "%JAVA_HOME%"=="" (
    if exist "C:\Program Files\Java\jdk-25.0.4" (
        set "JAVA_HOME=C:\Program Files\Java\jdk-25.0.4"
    ) else if exist "C:\Program Files\Java\latest" (
        set "JAVA_HOME=C:\Program Files\Java\latest"
    ) else (
        for /d %%D in ("C:\Program Files\Java\jdk*") do (
            set "JAVA_HOME=%%D"
        )
    )
)

if "%JAVA_HOME%"=="" (
    echo [ERROR] JAVA_HOME is not set and could not find JDK in standard path.
    echo Please make sure Java JDK 17, 21, or 25 is installed.
    pause
    exit /b 1
)

echo [OK] Using Java Home: %JAVA_HOME%
echo.

:: Free port 8085 if any previous process is still running
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8085 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" >nul 2>&1

:: Open browser after 4 seconds
start "" cmd /c "timeout /t 4 /nobreak >nul && start http://localhost:8085"

echo [INFO] Starting Spring Boot server on port 8085...
echo [INFO] Web application will automatically open at: http://localhost:8085
echo [INFO] Press Ctrl+C in this window anytime to stop the server.
echo.

call .\mvnw.cmd spring-boot:run

pause
